package plugin

type PluginConfig struct {
	Name    string
	Version string
	Exec    string
}
